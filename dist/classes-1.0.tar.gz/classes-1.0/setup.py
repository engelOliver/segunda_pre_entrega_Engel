from setuptools import setup


setup (
    
    name = 'classes',
    version = '1.0',
    description = 'Esta es la segunda pre entrega',
    author = 'Matias Oliver Engel',
    author_email = 'mati.engelvlol@gmail.com',

    packages = ['classes']

)